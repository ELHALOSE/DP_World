# Backdoor > 2025-04-15 4:38am
https://universe.roboflow.com/moemn-adel/backdoor-3hpzk

Provided by a Roboflow user
License: CC BY 4.0

